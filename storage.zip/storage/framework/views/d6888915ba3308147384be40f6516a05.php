

<?php $__env->startSection('title', 'Pembayaran'); ?>
<?php $__env->startSection('page_title', 'Pembayaran'); ?>
<?php $__env->startSection('breadcrumb', 'Home » Pembayaran'); ?>
<?php $__env->startSection('content'); ?>
<section class="py-16 bg-white min-h-screen">
    <div class="max-w-6xl mx-auto border border-gray-200 rounded-3xl bg-white shadow-md p-10">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Pembayaran Pesanan</h1>
            <p class="text-gray-600 mt-2">Order #<?php echo e($transaction->order_code); ?></p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-10">
            <div class="space-y-6">
                <h2 class="text-xl font-semibold text-gray-900 border-b border-gray-200 pb-2">Detail Produk</h2>
                <div class="space-y-4">
                    <?php $__currentLoopData = $transaction->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center gap-4 p-4 bg-gray-50 rounded-xl">
                        <img src="<?php echo e($item->product->image ? asset('storage/' . $item->product->image) : 'https://via.placeholder.com/80'); ?>"
                             alt="<?php echo e($item->product->product_name); ?>"
                             class="w-20 h-20 object-cover rounded-lg shadow-sm">
                        <div class="flex-1">
                            <h3 class="font-semibold text-gray-900"><?php echo e($item->product->product_name); ?></h3>
                            <p class="text-sm text-gray-600">Jumlah: <?php echo e($item->quantity); ?></p>
                            <p class="text-sm text-gray-600">Harga: Rp <?php echo e(number_format($item->price, 0, ',', '.')); ?></p>
                        </div>
                        <div class="text-right">
                            <p class="font-bold text-lg text-blue-600">Rp <?php echo e(number_format($item->price * $item->quantity, 0, ',', '.')); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="bg-gray-50 rounded-xl p-6 space-y-3">
                    <h3 class="text-lg font-semibold text-gray-900">Informasi Pengiriman</h3>
                    <div>
                        <p class="text-sm text-gray-600">Alamat</p>
                        <p class="font-medium text-gray-900"><?php echo e($transaction->address); ?></p>
                    </div>
                    <?php if($transaction->province && $transaction->city && $transaction->subdistrict): ?>
                    <div>
                        <p class="text-sm text-gray-600">Wilayah</p>
                        <p class="font-medium text-gray-900">
                            <?php echo e($transaction->subdistrict); ?>, <?php echo e($transaction->city); ?>, <?php echo e($transaction->province); ?>

                        </p>
                    </div>
                    <?php endif; ?>
                    <?php if($transaction->courier): ?>
                    <div>
                        <p class="text-sm text-gray-600">Kurir</p>
                        <p class="font-medium text-gray-900 uppercase"><?php echo e($transaction->courier); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if($transaction->courier_service): ?>
                    <div>
                        <p class="text-sm text-gray-600">Layanan</p>
                        <p class="font-medium text-gray-900"><?php echo e($transaction->courier_service); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if($transaction->shipping_cost): ?>
                    <div>
                        <p class="text-sm text-gray-600">Biaya Ongkir</p>
                        <p class="font-medium text-gray-900">Rp <?php echo e(number_format($transaction->shipping_cost, 0, ',', '.')); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if($transaction->tracking_number): ?>
                    <div>
                        <p class="text-sm text-gray-600">Nomor Resi</p>
                        <p class="font-medium text-gray-900"><?php echo e($transaction->tracking_number); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="space-y-6">
                <h2 class="text-xl font-semibold text-gray-900 border-b border-gray-200 pb-2">Ringkasan Pembayaran</h2>

                <div class="bg-gray-50 rounded-xl p-6 space-y-4">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Subtotal</span>
                        <span class="font-semibold">Rp <?php echo e(number_format($transaction->total - ($transaction->shipping_cost ?? 0), 0, ',', '.')); ?></span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Biaya Pengiriman</span>
                        <span class="font-semibold">Rp <?php echo e(number_format($transaction->shipping_cost ?? 0, 0, ',', '.')); ?></span>
                    </div>
                    <div class="border-t pt-4 flex justify-between">
                        <span class="font-bold text-lg">Total Pembayaran</span>
                        <span class="font-extrabold text-2xl text-blue-600">Rp <?php echo e(number_format($transaction->total, 0, ',', '.')); ?></span>
                    </div>
                </div>

                <div class="bg-white border border-gray-200 rounded-xl p-6">
                    <h3 class="text-lg font-semibold text-gray-900 mb-4">Status Pembayaran</h3>
                    <div class="flex items-center gap-3">
                        <?php
                            $statusColor = match($transaction->payment_status) {
                                'paid' => 'bg-green-500',
                                'pending' => 'bg-yellow-500',
                                'failed' => 'bg-red-500',
                                default => 'bg-gray-400'
                            };
                        ?>
                        <div class="w-4 h-4 rounded-full <?php echo e($statusColor); ?>"></div>
                        <span class="text-gray-700 capitalize"><?php echo e($transaction->payment_status); ?></span>
                    </div>
                </div>

                <div class="bg-white border border-gray-200 rounded-xl p-6 text-center">
                    <div id="payment-loading" class="space-y-4">
                        <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                        <h3 class="text-lg font-semibold text-gray-900">Memproses Pembayaran...</h3>
                        <p class="text-gray-600">Mohon tunggu sebentar, sedang mempersiapkan pembayaran Midtrans.</p>
                    </div>

                    <div id="payment-ready" class="hidden space-y-4">
                        <div class="text-green-600">
                            <svg class="w-16 h-16 mx-auto" fill="currentColor" viewBox="0 0 20 20">
                                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                            </svg>
                        </div>
                        <h3 class="text-lg font-semibold text-gray-900">Pembayaran Siap</h3>
                        <p class="text-gray-600">Modal pembayaran akan muncul dalam beberapa detik.</p>
                        <button id="manual-pay-btn"
                            class="bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition font-medium hidden">
                            Buka Pembayaran Manual
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://app.sandbox.midtrans.com/snap/snap.js"
    data-client-key="<?php echo e(config('services.midtrans.client_key')); ?>"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const loadingDiv = document.getElementById('payment-loading');
    const readyDiv = document.getElementById('payment-ready');
    const manualBtn = document.getElementById('manual-pay-btn');

    setTimeout(() => {
        loadingDiv.classList.add('hidden');
        readyDiv.classList.remove('hidden');
    }, 2000);

    setTimeout(() => {
        triggerPayment();
    }, 3000);

    manualBtn.addEventListener('click', triggerPayment);

    function triggerPayment() {
        fetch("<?php echo e(route('transaction.getSnapToken', $transaction->id)); ?>", {
            method: 'GET',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '',
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return response.json();
        })
        .then(data => {
            if (!data.snap_token) throw new Error("Snap token tidak ditemukan di server.");
            snap.pay(data.snap_token, {
                onSuccess: result => window.location.href = "<?php echo e(route('checkout.success', $transaction->id)); ?>",
                onPending: result => window.location.href = "<?php echo e(route('checkout.success', $transaction->id)); ?>",
                onError: result => {
                    alert("Pembayaran gagal. Silakan coba lagi.");
                    window.location.href = "<?php echo e(route('checkout.page')); ?>";
                },
                onClose: () => console.log("Modal pembayaran ditutup.")
            });
        })
        .catch(err => {
            alert("Tidak bisa memulai pembayaran. Coba refresh halaman");
            console.error(err);
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OnlineShop\resources\views/Checkout/Payment.blade.php ENDPATH**/ ?>