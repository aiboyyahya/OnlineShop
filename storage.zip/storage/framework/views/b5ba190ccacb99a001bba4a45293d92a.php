<?php
    use Carbon\Carbon;
    use App\Models\Transaction;

    $now = Carbon::now();

    // Bulan
    $months = [];
    for ($i = 1; $i <= 12; $i++) {
        $count = Transaction::whereYear('created_at', $now->year)->whereMonth('created_at', $i)->count();
        $monthName = Carbon::create()->month($i)->locale('id')->monthName;
        $months[$i] = "$monthName ({$count} orders)";
    }

    // Minggu
    $month = request('tableFilters.month.value', $now->month);
    $year = $now->year;
    $startOfMonth = Carbon::create($year, $month, 1)->startOfMonth();
    $endOfMonth = $startOfMonth->copy()->endOfMonth();
    $currentDate = $startOfMonth->copy();
    $weekNumber = 1;
    $weeks = [];
    while ($currentDate->lte($endOfMonth)) {
        $weekStart = $currentDate->copy()->startOfWeek();
        $weekEnd = $currentDate->copy()->endOfWeek();
        if ($weekEnd->gt($endOfMonth)) {
            $weekEnd = $endOfMonth;
        }
        $count = Transaction::whereBetween('created_at', [
            $weekStart->format('Y-m-d'),
            $weekEnd->format('Y-m-d'),
        ])->count();
        $weeks['week_' . $weekNumber] = "Minggu {$weekNumber} ({$count} orders)";
        $currentDate = $weekEnd->copy()->addDay();
        $weekNumber++;
    }
?>

<div class="bg-white rounded-lg border border-gray-200 shadow-sm p-3">
    <div class="flex items-center gap-4">
        <div class="text-sm font-medium text-gray-700">Filter:</div>
        <div class="flex gap-3 items-center">
            <select wire:model.live="tableFilters.month.value"
                class="px-3 py-1.5 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-50">
                <option value="">Bulan</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <select wire:model.live="tableFilters.week.value"
                class="px-3 py-1.5 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 bg-gray-50">
                <option value="">Minggu</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $weeks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
    </div>
</div>
<?php /**PATH D:\OnlineShop\resources\views/filament/tables/transaction-date-filters.blade.php ENDPATH**/ ?>