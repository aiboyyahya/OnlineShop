<div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
    <div class="p-6 text-gray-900 dark:text-gray-100">
        <div class="flex items-center">
            <h3 class="ml-2 text-lg font-medium text-gray-900 dark:text-gray-100">
                Total Pendapatan
            </h3>
        </div>
        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            Total pendapatan dari semua transaksi
        </p>
        <div class="mt-4">
            <p class="text-3xl font-bold text-green-600 dark:text-green-400">
                <?php echo e($totalPendapatan); ?>

            </p>
        </div>
    </div>
</div>
<?php /**PATH D:\OnlineShop\resources\views/filament/pendapatan/header.blade.php ENDPATH**/ ?>