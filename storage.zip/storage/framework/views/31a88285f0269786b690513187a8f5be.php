

<?php $__env->startSection('title', 'Detail Pesanan'); ?>
<?php $__env->startSection('page_title', 'Detail Pesanan'); ?>
<?php $__env->startSection('breadcrumb', 'Home » Detail pesanan » ' . $transaction->order_code); ?>
<?php $__env->startSection('content'); ?>

<section class="py-16 bg-white min-h-screen">
    <div class="max-w-7xl mx-auto px-6 lg:px-12">
        <div class="bg-white border border-gray-200 rounded-3xl shadow-md p-10 grid grid-cols-1 lg:grid-cols-3 gap-10">
           
            <div class="lg:col-span-2 space-y-8">
                <h1 class="text-4xl font-bold text-center ml-96 text-gray-900 mb-10">Detail Pesanan</h1>

                <div class="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                    <h3 class="font-semibold text-lg text-gray-900 mb-4">Produk dalam Pesanan</h3>
                    <div class="space-y-4">
                        <?php $__currentLoopData = $transaction->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex gap-4 items-center">
                            <img src="<?php echo e($item->product->image ? asset('storage/' . $item->product->image) : 'https://via.placeholder.com/100'); ?>"
                                 alt="<?php echo e($item->product->product_name); ?>"
                                 class="w-20 h-20 object-cover rounded-lg" />
                            <div class="flex-1">
                                <p class="font-semibold text-gray-900"><?php echo e($item->product->product_name); ?></p>
                                <p class="text-sm text-gray-600">Jumlah: <?php echo e($item->quantity); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                <div class="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                    <div class="flex flex-col md:flex-row justify-between gap-6 text-sm font-medium text-gray-700">
                        <div>
                            <p class="text-gray-900 mb-1 font-semibold">Nomor Pesanan</p>
                            <p>#<?php echo e($transaction->order_code); ?></p>
                        </div>
                        <div>
                            <p class="text-gray-900 mb-1 font-semibold">Tanggal Pemesanan</p>
                            <p><?php echo e($transaction->created_at->translatedFormat('d M Y')); ?></p>
                        </div>
                        <div>
                            <p class="text-gray-900 mb-1 font-semibold">Tanggal Dikirim</p>
                            <p><?php if($transaction->status === 'sent'): ?> <?php echo e($transaction->updated_at->translatedFormat('d M Y')); ?> <?php else: ?> - <?php endif; ?></p>
                        </div>
                        <div>
                            <p class="text-gray-900 mb-1 font-semibold">Jumlah Barang</p>
                            <p><?php echo e($transaction->items->count()); ?> produk</p>
                        </div>
                        <div>
                            <p class="text-gray-900 mb-1 font-semibold">Status</p>
                            <span class="capitalize"><?php echo e($transaction->status); ?></span>
                        </div>
                    </div>
                </div>

                <div class="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm">
                    <h3 class="font-semibold text-lg mb-4 text-gray-900">Informasi Pengiriman</h3>
                    <div class="grid md:grid-cols-2 gap-6 text-sm text-gray-700">
                        <div>
                            <p class="font-semibold text-gray-900 mb-1">Nomor Resi</p>
                            <p><?php echo e($transaction->tracking_number ?? '-'); ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-900 mb-1">Alamat Lengkap</p>
                            <p><?php echo e($transaction->address ?? '-'); ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-900 mb-1">Provinsi</p>
                            <p><?php echo e($transaction->province ?? '-'); ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-900 mb-1">Kota / Kabupaten</p>
                            <p><?php echo e($transaction->city ?? '-'); ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-900 mb-1">Kecamatan</p>
                            <p><?php echo e($transaction->district ?? '-'); ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-900 mb-1">Kurir</p>
                            <p class="uppercase"><?php echo e($transaction->courier ?? '-'); ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-900 mb-1">Layanan</p>
                            <p><?php echo e($transaction->courier_service ?? '-'); ?></p>
                        </div>
                        <div>
                            <p class="font-semibold text-gray-900 mb-1">Ongkos Kirim</p>
                            <p>Rp <?php echo e(number_format($transaction->shipping_cost ?? 0, 0, ',', '.')); ?></p>
                        </div>
                    </div>
                </div>

                <?php
                    $steps = [
                        ['key' => 'pending', 'label' => 'Pesanan Dibuat', 'date' => $transaction->created_at->translatedFormat('d M Y')],
                        ['key' => 'packing', 'label' => 'Dikemas', 'date' => $transaction->created_at->addDay()->translatedFormat('d M Y')],
                        ['key' => 'sent', 'label' => 'Dikirim', 'date' => $transaction->created_at->addDays(2)->translatedFormat('d M Y')],
                        ['key' => 'done', 'label' => 'Selesai', 'date' => $transaction->updated_at->translatedFormat('d M Y')],
                    ];
                    $orderKeys = array_column($steps, 'key');
                    $currentStep = array_search($transaction->status, $orderKeys);
                ?>

                <div class="bg-white border border-gray-200 rounded-2xl p-6 shadow-sm w-full">
                    <h3 class="font-semibold text-lg mb-4 text-gray-900">Pelacakan Pesanan</h3>
                    <div class="flex items-center justify-between overflow-x-auto w-full">
                        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $isActive = $index <= $currentStep;
                                $circleColor = $isActive ? 'bg-orange-500 text-white' : 'bg-gray-300 text-gray-500';
                            ?>
                            <div class="flex flex-col items-center min-w-[90px] relative text-center">
                                <div class="rounded-full w-12 h-12 flex items-center justify-center mb-2 <?php echo e($circleColor); ?>">
                                    <?php echo e($loop->iteration); ?>

                                </div>
                                <span class="font-semibold text-sm text-gray-900"><?php echo e($step['label']); ?></span>
                                <span class="text-xs text-gray-500"><?php echo e($step['date']); ?></span>
                                <?php if($index < count($steps) - 1): ?>
                                    <div class="absolute top-6 left-full w-16 h-1 bg-gray-300">
                                        <?php if($isActive && ($index + 1) <= $currentStep): ?>
                                        <div class="h-1 bg-blue-500 w-full"></div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="rounded-3xl bg-white border border-gray-200 p-6 flex flex-col space-y-6 shadow-sm h-fit mt-20">
                <h3 class="font-bold text-xl text-gray-900">Ringkasan Pembayaran</h3>

                <div class="text-gray-700 text-sm space-y-3">
                    <div class="flex justify-between items-center">
                        <span>Subtotal</span>
                        <span class="font-semibold text-gray-900">Rp <?php echo e(number_format($transaction->total - ($transaction->shipping_cost ?? 0), 0, ',', '.')); ?></span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span>Ongkos Kirim</span>
                        <span class="font-semibold text-gray-900">
                            Rp <?php echo e(number_format($transaction->shipping_cost ?? 0, 0, ',', '.')); ?>

                        </span>
                    </div>
                </div>

                <div class="border-t pt-4 flex justify-between font-semibold text-lg text-gray-900">
                    <span>Total</span>
                    <span class="text-gray-600 font-bold">
                       Rp <?php echo e(number_format($transaction->total, 0, ',', '.')); ?>

                    </span>
                </div>

                <div class="flex flex-wrap gap-3 pt-4">
                    <?php if($transaction->payment_status == 'pending' && $transaction->status != 'done'): ?>
                    <a href="<?php echo e(route('checkout.payment', $transaction->id)); ?>"
                        class="w-full bg-black hover:bg-gray-700 text-white font-semibold py-3 rounded-lg text-center transition">
                        Bayar Sekarang
                    </a>
                    <?php elseif($transaction->status == 'done'): ?>
                    <a href="<?php echo e(route('home')); ?>"
                        class="w-full bg-black hover:bg-gray-700 text-white font-semibold py-3 rounded-lg text-center transition">
                        Beli Lagi
                    </a>
                    <?php endif; ?>

                    <a href="<?php echo e(route('orders')); ?>"
                        class="w-full border border-black text-gray-700 font-medium py-3 rounded-lg text-center hover:bg-gray-100 transition">
                        Kembali ke Pesanan
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\OnlineShop\resources\views/detail-pesanan.blade.php ENDPATH**/ ?>