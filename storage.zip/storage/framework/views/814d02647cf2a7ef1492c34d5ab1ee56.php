<?php
    $tabs = [
        'all' => 'All',
        'pending' => 'Pending',
        'packing' => 'Packing',
        'sent' => 'Sent',
        'done' => 'Done',
        'cancelled' => 'Cancelled',
    ];

    $active = request('status', 'all');
?>

<div class="fi-tabs flex justify-center gap-1 p-1 bg-gray-100 rounded-xl w-full ">

    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button
            type="button"
            role="tab"
            onclick="window.location='<?php echo e(request()->fullUrlWithQuery(['status' => $key])); ?>'"
            class="fi-tabs-item px-4 py-2 rounded-lg text-sm
                <?php echo e($active === $key ? 'fi-active bg-white shadow' : ''); ?>"
        >
            <span class="fi-tabs-item-label">
                <?php echo e($label); ?>

            </span>
        </button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php /**PATH D:\OnlineShop\resources\views/filament/tables/transaction-status-tabs.blade.php ENDPATH**/ ?>